#include <stdio.h>
#include <stdlib.h>
#include "rand.h"
#include "mat.h"   // include matrix lib

// INPUT: <number dimensions> <number trials>
// OUTPUT: Y if in the unit sphere "." if not
// random points in d space selected and ask if point is in the sphere
// the Y and . give a viseral feel for frequency of inside sphere.
// OBSERVATION: as dimension goes up freq of inside sphere goes way down

// helper function
double distance(int size, double *x)
{
    double sum;

    sum = 0;
    for (int i=0; i<size; i++) sum += x[i]*x[i];

    return sqrt(sum);
}


int main(int argc, char *argv[])
{

    int dmax=atoi(argv[1]);
    int maxTrials=atoi(argv[2]);
    double absmax;

    Matrix ptA(maxTrials, dmax, "A"), ptB(maxTrials, dmax, "B");
    Matrix d("distances");

    initRand();

    absmax = 2*sqrt(dmax);
    printf("MAXDIST: %9.5lf\n", absmax);

    ptA.rand(-1.0, 1.0);
    ptB.rand(-1.0, 1.0);
    ptA.sub(ptB);
    d = ptA.mapRow(distance);
    printf("Min: %9.5lf  Max: %9.5lf  RelSpread: %9.5lf  Mean: %9.5lf  StdDev: %9.5lf\n",
           d.min(),
           d.max(),
           (d.max()-d.min())/absmax,
           d.mean(),
           d.stddev());
    printf("StdDev: %9.5f\n", d.stddevCol(0));
    d.stddevVec().print("StdDev:");

    return 0;
}
