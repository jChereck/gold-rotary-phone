#include <stdio.h>
#include <stdlib.h>
#include "rand.h"
#include "mat.h"   // include matrix lib

// INPUT: <number dimensions> <number trials>
// OUTPUT: Y if in the unit sphere "." if not
// random points in d space selected and ask if point is in the sphere
// the Y and . give a viseral feel for frequency of inside sphere.
// OBSERVATION: as dimension goes up freq of inside sphere goes way down

// helper function
// square of distance
double distance2(int size, double *x)
{
    double sum;

    sum = 0;
    for (int i=0; i<size; i++) sum += x[i]*x[i];

    // side effect!
    if (sum<=1.0) printf("Y");
    else printf(".");

    return sum;
}


int main(int argc, char *argv[])
{

    int dmax=atoi(argv[1]);
    int maxTrials=atoi(argv[2]);

    initRand();

    Matrix data(maxTrials, dmax, "mydata");

    // demonstration of when matrices are changed in place vs returned
    data.rand(0, 10);
    data.print();
    data.mapRow(distance2).print();
    data.print();

    // now solve problem of insphere
    Matrix d("distances");

    data.rand(-1.0, 1.0);
    d = data.mapRow(distance2);
    printf("\nMin: %lf  Mean: %lf  Max: %lf  StdDev: %lf\n", d.min(), d.mean(), d.max(), d.stddev());

    // make a mistake
    d.dot(d);

    return 0;
}
